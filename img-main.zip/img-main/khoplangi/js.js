$(document).ready(function(){
        $("#login2").on('click',function(){
                $("#login").css("display","flex")
                $("#signup").css("display","none")


        })
        $("#signin1").on('click',function(){
                $("#signup").css("display","flex")
                $("#login").css("display","none")


        })
})